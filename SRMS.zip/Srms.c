#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define STUDENT_FILE    "students.txt"
#define CREDENTIAL_FILE "credentials.txt"

#define MAX_NAME  50
#define MAX_USER  50
#define MAX_ROLE  20
#define MAX_STUD  1000

struct Student {
    int   roll;
    char  name[MAX_NAME];
    float marks;
};

/* current user info */
char currentUser[MAX_USER];
char currentRole[MAX_ROLE];

/* function prototypes */
int  loginSystem(void);
void registerUser(void);
void mainMenuRouter(void);

void adminMenu(void);
void staffMenu(void);
void userMenu(void);
void guestMenu(void);

void addStudent(void);
void viewStudents(void);
void searchByRoll(void);
void searchByName(void);
void updateStudent(void);
void deleteStudent(void);

/* helpers */
int  rollExists(int roll);
void toLowerStr(const char *src, char *dst);

/* -------------------- MAIN -------------------- */
int main(void) {
    printf("=====================================\n");
    printf("       STUDENT MANAGEMENT SYSTEM\n");
    printf("=====================================\n");

    while (1) {
        int choice;
        printf("\n1. Login\n2. Register\n3. Continue as Guest\n4. Exit\n");
        printf("Enter choice: ");
        if (scanf("%d", &choice) != 1) {
            while (getchar() != '\n');
            printf("Invalid input.\n");
            continue;
        }

        switch (choice) {
            case 1:
                if (loginSystem()) {
                    mainMenuRouter();
                } else {
                    printf("Login failed.\n");
                }
                break;
            case 2:
                registerUser();
                break;
            case 3:
                strcpy(currentRole, "GUEST");
                strcpy(currentUser, "guest");
                guestMenu();
                break;
            case 4:
                printf("Exiting program. Goodbye!\n");
                return 0;
            default:
                printf("Invalid choice. Try again.\n");
        }
    }
}

/* -------------------- LOGIN -------------------- */
int loginSystem(void) {
    char username[MAX_USER];
    char password[MAX_USER];
    char fileUser[MAX_USER], filePass[MAX_USER], fileRole[MAX_ROLE];
    int attempts = 3;

    printf("\n===== LOGIN =====\n");
    printf("Username: ");
    if (scanf("%49s", username) != 1) return 0;

    while (attempts > 0) {
        printf("Password (%d attempts left): ", attempts);
        if (scanf("%49s", password) != 1) return 0;

        FILE *fp = fopen(CREDENTIAL_FILE, "r");
        if (!fp) {
            printf("Error: %s not found! You can register a user.\n", CREDENTIAL_FILE);
            return 0;
        }

        int found = 0;
        while (fscanf(fp, "%49s %49s %19s", fileUser, filePass, fileRole) == 3) {
            if (strcmp(username, fileUser) == 0 && strcmp(password, filePass) == 0) {
                strcpy(currentUser, fileUser);
                strcpy(currentRole, fileRole);
                found = 1;
                break;
            }
        }
        fclose(fp);

        if (found) {
            printf("\nLogin successful! Welcome %s (Role: %s)\n",
                   currentUser, currentRole);
            return 1;
        }

        attempts--;
        printf("Incorrect password or user not found!\n");
    }

    printf("Too many attempts. Login failed.\n");
    return 0;
}

/* -------------------- REGISTER -------------------- */
void registerUser(void) {
    char username[MAX_USER], password[MAX_USER], role[MAX_ROLE];
    char fu[MAX_USER], fpw[MAX_USER], fr[MAX_ROLE];

    printf("\n===== REGISTER NEW USER =====\n");
    printf("Enter username: ");
    if (scanf("%49s", username) != 1) return;
    printf("Enter password: ");
    if (scanf("%49s", password) != 1) return;
    printf("Enter role (ADMIN/STAFF/USER/GUEST): ");
    if (scanf("%19s", role) != 1) return;

    /* check if username already exists */
    FILE *fp = fopen(CREDENTIAL_FILE, "r");
    if (fp) {
        while (fscanf(fp, "%49s %49s %19s", fu, fpw, fr) == 3) {
            if (strcmp(fu, username) == 0) {
                printf("Username already exists. Registration cancelled.\n");
                fclose(fp);
                return;
            }
        }
        fclose(fp);
    }

    /* save new user */
    fp = fopen(CREDENTIAL_FILE, "a");
    if (!fp) {
        printf("Unable to open %s for writing.\n", CREDENTIAL_FILE);
        return;
    }
    fprintf(fp, "%s %s %s\n", username, password, role);
    fclose(fp);
    printf("User registered successfully. You may now login.\n");
}

/* -------------------- ROUTER -------------------- */
void mainMenuRouter(void) {
    if (strcmp(currentRole, "ADMIN") == 0 || strcmp(currentRole, "admin") == 0)
        adminMenu();
    else if (strcmp(currentRole, "STAFF") == 0 || strcmp(currentRole, "staff") == 0)
        staffMenu();
    else if (strcmp(currentRole, "USER") == 0 || strcmp(currentRole, "user") == 0)
        userMenu();
    else
        guestMenu();
}

/* -------------------- ADMIN MENU -------------------- */
void adminMenu(void) {
    int ch;
    while (1) {
        printf("\n========== ADMIN MENU (%s) ==========\n", currentUser);
        printf("1. Add Student\n");
        printf("2. View Students\n");
        printf("3. Search Student by Roll\n");
        printf("4. Search Student by Name\n");
        printf("5. Update Student\n");
        printf("6. Delete Student\n");
        printf("7. Logout\n");
        printf("Enter choice: ");
        if (scanf("%d", &ch) != 1) {
            while (getchar() != '\n');
            printf("Invalid input.\n");
            continue;
        }

        switch (ch) {
            case 1: addStudent();      break;
            case 2: viewStudents();    break;
            case 3: searchByRoll();    break;
            case 4: searchByName();    break;
            case 5: updateStudent();   break;
            case 6: deleteStudent();   break;
            case 7: return;
            default: printf("Invalid choice!\n");
        }
    }
}

/* -------------------- STAFF MENU -------------------- */
void staffMenu(void) {
    int ch;
    while (1) {
        printf("\n========== STAFF MENU (%s) ==========\n", currentUser);
        printf("1. Add Student\n");
        printf("2. View Students\n");
        printf("3. Search Student by Roll\n");
        printf("4. Search Student by Name\n");
        printf("5. Logout\n");
        printf("Enter choice: ");
        if (scanf("%d", &ch) != 1) {
            while (getchar() != '\n');
            printf("Invalid input.\n");
            continue;
        }

        switch (ch) {
            case 1: addStudent();      break;
            case 2: viewStudents();    break;
            case 3: searchByRoll();    break;
            case 4: searchByName();    break;
            case 5: return;
            default: printf("Invalid choice!\n");
        }
    }
}

/* -------------------- USER MENU -------------------- */
void userMenu(void) {
    int ch;
    while (1) {
        printf("\n=========== USER MENU (%s) ===========\n", currentUser);
        printf("1. View Students\n");
        printf("2. Search Student by Roll\n");
        printf("3. Search Student by Name\n");
        printf("4. Logout\n");
        printf("Enter choice: ");
        if (scanf("%d", &ch) != 1) {
            while (getchar() != '\n');
            printf("Invalid input.\n");
            continue;
        }

        switch (ch) {
            case 1: viewStudents();    break;
            case 2: searchByRoll();    break;
            case 3: searchByName();    break;
            case 4: return;
            default: printf("Invalid choice!\n");
        }
    }
}

/* -------------------- GUEST MENU -------------------- */
void guestMenu(void) {
    int ch;
    while (1) {
        printf("\n=========== GUEST MENU ===========\n");
        printf("1. View Students\n");
        printf("2. Search Student by Roll\n");
        printf("3. Search Student by Name\n");
        printf("4. Back to Main\n");
        printf("Enter choice: ");
        if (scanf("%d", &ch) != 1) {
            while (getchar() != '\n');
            printf("Invalid input.\n");
            continue;
        }

        switch (ch) {
            case 1: viewStudents();    break;
            case 2: searchByRoll();    break;
            case 3: searchByName();    break;
            case 4: return;
            default: printf("Invalid choice!\n");
        }
    }
}

/* -------------------- ADD STUDENT -------------------- */
void addStudent(void) {
    struct Student st;
    FILE *fp;

    printf("\nEnter Roll: ");
    if (scanf("%d", &st.roll) != 1) {
        while (getchar() != '\n');
        printf("Invalid roll.\n");
        return;
    }

    if (rollExists(st.roll)) {
        printf("A student with roll %d already exists. Not added.\n", st.roll);
        return;
    }

    printf("Enter Name (no spaces): ");
    if (scanf("%49s", st.name) != 1) {
        printf("Invalid name.\n");
        return;
    }

    printf("Enter Marks: ");
    if (scanf("%f", &st.marks) != 1) {
        while (getchar() != '\n');
        printf("Invalid marks.\n");
        return;
    }

    fp = fopen(STUDENT_FILE, "a+");
    if (!fp) {
        printf("Error opening %s for writing.\n", STUDENT_FILE);
        return;
    }

    /* Add heading only if file is empty */
    fseek(fp, 0, SEEK_END);
    if (ftell(fp) == 0) {
        fprintf(fp, "ROLL NAME MARKS\n");
    }

    fprintf(fp, "%d %s %.2f\n", st.roll, st.name, st.marks);
    fclose(fp);

    printf("Student added successfully!\n");
}

/* -------------------- VIEW STUDENTS -------------------- */
void viewStudents(void) {
    struct Student st;
    FILE *fp = fopen(STUDENT_FILE, "r");
    if (!fp) {
        printf("No student records found.\n");
        return;
    }

    char header[100];
    if (!fgets(header, sizeof(header), fp)) {
        fclose(fp);
        printf("No student data.\n");
        return;
    }

    printf("\nROLL\tNAME\tMARKS\n");
    printf("---------------------------\n");

    while (fscanf(fp, "%d %49s %f", &st.roll, st.name, &st.marks) == 3) {
        printf("%d\t%s\t%.2f\n", st.roll, st.name, st.marks);
    }
    fclose(fp);
}

/* -------------------- SEARCH BY ROLL -------------------- */
void searchByRoll(void) {
    struct Student st;
    int roll, found = 0;

    FILE *fp = fopen(STUDENT_FILE, "r");
    if (!fp) {
        printf("No student records found.\n");
        return;
    }

    char header[100];
    if (!fgets(header, sizeof(header), fp)) {
        fclose(fp);
        printf("No student data.\n");
        return;
    }

    printf("Enter Roll to search: ");
    if (scanf("%d", &roll) != 1) {
        while (getchar() != '\n');
        fclose(fp);
        printf("Invalid roll.\n");
        return;
    }

    while (fscanf(fp, "%d %49s %f", &st.roll, st.name, &st.marks) == 3) {
        if (st.roll == roll) {
            printf("\nRecord Found:\nRoll: %d\nName: %s\nMarks: %.2f\n",
                   st.roll, st.name, st.marks);
            found = 1;
            break;
        }
    }

    if (!found) printf("Record not found.\n");
    fclose(fp);
}

/* -------------------- SEARCH BY NAME -------------------- */
void searchByName(void) {
    struct Student st;
    char search[MAX_NAME], lowerSearch[MAX_NAME], lowerName[MAX_NAME];
    int found = 0;

    FILE *fp = fopen(STUDENT_FILE, "r");
    if (!fp) {
        printf("No student records found.\n");
        return;
    }

    char header[100];
    if (!fgets(header, sizeof(header), fp)) {
        fclose(fp);
        printf("No student data.\n");
        return;
    }

    printf("Enter Name to search: ");
    if (scanf("%49s", search) != 1) {
        fclose(fp);
        printf("Invalid name.\n");
        return;
    }

    toLowerStr(search, lowerSearch);

    while (fscanf(fp, "%d %49s %f", &st.roll, st.name, &st.marks) == 3) {
        toLowerStr(st.name, lowerName);

        if (strcmp(lowerSearch, lowerName) == 0) {
            printf("\nRecord Found:\nRoll: %d\nName: %s\nMarks: %.2f\n",
                   st.roll, st.name, st.marks);
            found = 1;
            break;
        }
    }

    if (!found) printf("Name not found.\n");
    fclose(fp);
}

/* -------------------- UPDATE STUDENT -------------------- */
void updateStudent(void) {
    struct Student list[MAX_STUD];
    int count = 0, found = 0;
    int roll, i;

    FILE *fp = fopen(STUDENT_FILE, "r");
    if (!fp) {
        printf("No student records found.\n");
        return;
    }

    char header[100];
    if (!fgets(header, sizeof(header), fp)) {
        fclose(fp);
        printf("No student data.\n");
        return;
    }

    while (count < MAX_STUD &&
           fscanf(fp, "%d %49s %f", &list[count].roll, list[count].name, &list[count].marks) == 3) {
        count++;
    }
    fclose(fp);

    printf("Enter Roll to update: ");
    if (scanf("%d", &roll) != 1) {
        while (getchar() != '\n');
        printf("Invalid roll.\n");
        return;
    }

    for (i = 0; i < count; i++) {
        if (list[i].roll == roll) {
            found = 1;
            printf("Existing: Roll:%d Name:%s Marks:%.2f\n",
                   list[i].roll, list[i].name, list[i].marks);

            printf("Enter new Name (no spaces): ");
            if (scanf("%49s", list[i].name) != 1) {
                printf("Invalid name.\n");
                return;
            }
            printf("Enter new Marks: ");
            if (scanf("%f", &list[i].marks) != 1) {
                while (getchar() != '\n');
                printf("Invalid marks.\n");
                return;
            }
            break;
        }
    }

    if (!found) {
        printf("Record not found.\n");
        return;
    }

    fp = fopen(STUDENT_FILE, "w");
    if (!fp) {
        printf("Error writing to file.\n");
        return;
    }

    fprintf(fp, "ROLL NAME MARKS\n");
    for (i = 0; i < count; i++) {
        fprintf(fp, "%d %s %.2f\n", list[i].roll, list[i].name, list[i].marks);
    }
    fclose(fp);

    printf("Record updated successfully.\n");
}

/* -------------------- DELETE STUDENT -------------------- */
void deleteStudent(void) {
    struct Student list[MAX_STUD];
    int count = 0, found = 0;
    int roll, i, j;

    FILE *fp = fopen(STUDENT_FILE, "r");
    if (!fp) {
        printf("No student records found.\n");
        return;
    }

    char header[100];
    if (!fgets(header, sizeof(header), fp)) {
        fclose(fp);
        printf("No student data.\n");
        return;
    }

    while (count < MAX_STUD &&
           fscanf(fp, "%d %49s %f", &list[count].roll, list[count].name, &list[count].marks) == 3) {
        count++;
    }
    fclose(fp);

    printf("Enter Roll to delete: ");
    if (scanf("%d", &roll) != 1) {
        while (getchar() != '\n');
        printf("Invalid roll.\n");
        return;
    }

    for (i = 0; i < count; i++) {
        if (list[i].roll == roll) {
            found = 1;
            for (j = i; j < count - 1; j++) {
                list[j] = list[j + 1];
            }
            count--;
            break;
        }
    }

    if (!found) {
        printf("Record not found.\n");
        return;
    }

    fp = fopen(STUDENT_FILE, "w");
    if (!fp) {
        printf("Error writing to file.\n");
        return;
    }

    fprintf(fp, "ROLL NAME MARKS\n");
    for (i = 0; i < count; i++) {
        fprintf(fp, "%d %s %.2f\n", list[i].roll, list[i].name, list[i].marks);
    }
    fclose(fp);

    printf("Record deleted successfully.\n");
}

/* -------------------- HELPERS -------------------- */

int rollExists(int roll) {
    struct Student st;
    FILE *fp = fopen(STUDENT_FILE, "r");
    if (!fp) return 0;

    char header[100];
    if (!fgets(header, sizeof(header), fp)) {
        fclose(fp);
        return 0;
    }

    while (fscanf(fp, "%d %49s %f", &st.roll, st.name, &st.marks) == 3) {
        if (st.roll == roll) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

void toLowerStr(const char *src, char *dst) {
    int i = 0;
    while (src[i]) {
        dst[i] = (char)tolower((unsigned char)src[i]);
        i++;
    }
    dst[i] = '\0';
}
